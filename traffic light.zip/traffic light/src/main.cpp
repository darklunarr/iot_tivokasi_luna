#include <Arduino.h>

int ledMerah = 26;
int ledKuning = 32;
int ledHijau = 33;

void setup()
{
  Serial.begin(115200);
  Serial.println("ESP32 Traffic Light Simulation");

  // Atur pin sebagai OUTPUT
  pinMode(ledMerah, OUTPUT);
  pinMode(ledKuning, OUTPUT);
  pinMode(ledHijau, OUTPUT);
}

void loop()
{
  // Lampu Merah menyala selama 5 detik
  digitalWrite(ledMerah, HIGH);
  digitalWrite(ledKuning, LOW);
  digitalWrite(ledHijau, LOW);
  Serial.println("Lampu Merah ON");
  delay(5000);

  // Lampu Kuning menyala selama 2 detik
  digitalWrite(ledMerah, LOW);
  digitalWrite(ledKuning, HIGH);
  digitalWrite(ledHijau, LOW);
  Serial.println("Lampu Kuning ON");
  delay(2000);

  // Lampu Hijau menyala selama 5 detik
  digitalWrite(ledMerah, LOW);
  digitalWrite(ledKuning, LOW);
  digitalWrite(ledHijau, HIGH);
  Serial.println("Lampu Hijau ON");
  delay(5000);
}